# README

Order Reference: 2021-05-13-e339905
Licensee: Camila Mercado
E-mail: camilamercado11@gmail.com

## Fonts included:
* Roslindale Series

Your purchase entitles you to use the fonts according to the following limitations:

### Testing License

* 1 desktop workstation, for testing purposes only
* 0 monthly unique web visitors, for testing purposes only
* 0 apps or e-books, for testing purposes only
            
Please refer to LICENSE.txt for the full terms of the license. If you would like to exceed any of these limitations, you can purchase an upgrade by contacting me at david@djr.com.

## Using the fonts

Please refer to INSTALL.txt for desktop installation instructions and font cache troubleshooting.

For an example of how to use the web font files via CSS @font-face, please consult the CSS file included in the web fonts folder.

Happy typesetting!

- DJR